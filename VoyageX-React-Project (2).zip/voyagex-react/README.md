# VoyageX — React + Vite Project

A React + Vite wrapper around the supplied VoyageX travel-booking interface, with a Local Storage authentication flow and a separate Admin module.

## Run locally

1. Install Node.js (LTS).
2. Open this folder in VS Code.
3. In the terminal run:

```bash
npm install
npm run dev
```

4. Open the local URL printed by Vite (usually http://localhost:5173).

## Demo accounts

- Admin email: `admin@voyagex.com`
- Admin password: `Admin123`
- User: create an account from **Register**, then sign in with that email and password.

## Modules

### User module
- Browse the supplied flights, hotels, cabs and travel packages interface.
- Create an account and sign in.
- User accounts and session are saved in browser Local Storage.
- Booking confirmation records are saved in Local Storage and require a signed-in user.

### Admin module
- Open **Admin** in the top navigation.
- Admin dashboard with counts for users, packages and bookings.
- Add, edit and delete travel packages.
- View registered users and booking records.

## Local Storage keys

- `voyagex_users` — registered user accounts (demo only; passwords are stored in plain text).
- `voyagex_session` — currently signed-in user.
- `voyagex_packages` — editable demo packages.
- `voyagex_bookings` — confirmed demo bookings.

## Important project-review note

This is a front-end academic demo. Local Storage authentication is not secure and is not suitable for real customers. The booking/payment screens are demonstrations; no real airline, hotel, payment gateway or backend service is connected. Do not enter real payment-card or identity details.

## Deploy to Vercel

1. Push this project folder to a GitHub repository.
2. In Vercel choose **Add New → Project**, import that GitHub repository.
3. Framework preset: **Vite**. Build command: `npm run build`. Output directory: `dist`.
4. Deploy and copy the generated URL for your project review.
