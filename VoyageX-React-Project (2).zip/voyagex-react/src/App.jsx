import React, { useEffect, useMemo, useState } from 'react'
import legacyHtml from './legacy.html?raw'
import { LayoutDashboard, Users, Package, ClipboardList, LogOut, X, Plus, Trash2, Pencil, ShieldCheck } from 'lucide-react'

const read = (key, fallback = []) => { try { return JSON.parse(localStorage.getItem(key)) ?? fallback } catch { return fallback } }
const seedPackages = [
  { id: 'PKG-001', name: 'Bali Escape', destination: 'Bali, Indonesia', price: 899, days: 6, description: 'Beaches, temples and island stays.' },
  { id: 'PKG-002', name: 'Swiss Alps Journey', destination: 'Switzerland', price: 1499, days: 7, description: 'Mountain views and scenic rail journeys.' },
  { id: 'PKG-003', name: 'Dubai City Break', destination: 'Dubai, UAE', price: 699, days: 4, description: 'A modern city break with desert experiences.' }
]

function AdminPanel({ onClose }) {
  const [loggedIn, setLoggedIn] = useState(false)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [tab, setTab] = useState('overview')
  const [packages, setPackages] = useState(() => read('voyagex_packages', seedPackages))
  const [users, setUsers] = useState(() => read('voyagex_users'))
  const [bookings, setBookings] = useState(() => read('voyagex_bookings'))
  const [editing, setEditing] = useState(null)
  const [draft, setDraft] = useState({ name: '', destination: '', price: '', days: '', description: '' })

  useEffect(() => { if (!localStorage.getItem('voyagex_packages')) localStorage.setItem('voyagex_packages', JSON.stringify(seedPackages)) }, [])
  const refresh = () => { setUsers(read('voyagex_users')); setBookings(read('voyagex_bookings')); setPackages(read('voyagex_packages', seedPackages)) }
  const login = e => { e.preventDefault(); if (email.trim().toLowerCase() === 'admin@voyagex.com' && password === 'Admin123') { setLoggedIn(true); setError('') } else setError('Incorrect admin email or password.') }
  const savePackage = e => {
    e.preventDefault()
    if (!draft.name.trim() || !draft.destination.trim() || Number(draft.price) <= 0 || Number(draft.days) <= 0) return
    const next = editing ? packages.map(p => p.id === editing ? { ...draft, id: editing, price: Number(draft.price), days: Number(draft.days) } : p) : [...packages, { ...draft, id: 'PKG-' + Date.now(), price: Number(draft.price), days: Number(draft.days) }]
    setPackages(next); localStorage.setItem('voyagex_packages', JSON.stringify(next)); setEditing(null); setDraft({ name: '', destination: '', price: '', days: '', description: '' })
  }
  const removePackage = id => { const next = packages.filter(p => p.id !== id); setPackages(next); localStorage.setItem('voyagex_packages', JSON.stringify(next)) }
  const editPackage = p => { setEditing(p.id); setDraft({ name: p.name, destination: p.destination, price: p.price, days: p.days, description: p.description || '' }); setTab('packages') }
  const tabs = [{ id: 'overview', label: 'Overview', icon: LayoutDashboard }, { id: 'packages', label: 'Packages', icon: Package }, { id: 'users', label: 'Users', icon: Users }, { id: 'bookings', label: 'Bookings', icon: ClipboardList }]

  return <div className="admin-backdrop" role="dialog" aria-modal="true">
    <section className="admin-shell">
      <header className="admin-top"><div className="admin-brand"><ShieldCheck size={21}/> <span>VoyageX <b>Admin</b></span></div><button className="admin-close" onClick={onClose} aria-label="Close"><X/></button></header>
      {!loggedIn ? <form className="admin-login" onSubmit={login}><div className="admin-login-mark"><ShieldCheck size={30}/></div><h2>Admin sign in</h2><p>Sign in to manage the VoyageX demo portal.</p><label>Email address<input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="admin@voyagex.com" required /></label><label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Enter admin password" required /></label>{error && <div className="admin-error">{error}</div>}<button className="admin-primary">Sign in to dashboard</button><small>Demo credentials: admin@voyagex.com / Admin123</small></form> : <div className="admin-layout">
        <aside className="admin-sidebar"><div className="admin-side-label">WORKSPACE</div>{tabs.map(t=><button key={t.id} className={tab===t.id?'selected':''} onClick={()=>{setTab(t.id);refresh()}}><t.icon size={17}/>{t.label}</button>)}<button className="admin-logout" onClick={()=>setLoggedIn(false)}><LogOut size={17}/>Sign out</button></aside>
        <main className="admin-content">
          <div className="admin-heading"><div><span>ADMINISTRATION</span><h1>{tabs.find(t=>t.id===tab)?.label}</h1></div><button className="admin-refresh" onClick={refresh}>Refresh data</button></div>
          {tab==='overview' && <><div className="admin-stats"><div><span>Total users</span><strong>{users.length}</strong></div><div><span>Travel packages</span><strong>{packages.length}</strong></div><div><span>Total bookings</span><strong>{bookings.length}</strong></div><div><span>Confirmed</span><strong>{bookings.filter(b=>b.status==='Confirmed').length}</strong></div></div><div className="admin-card"><h3>Recent bookings</h3><BookingTable bookings={bookings.slice(-5).reverse()}/></div><div className="admin-card"><h3>Quick actions</h3><div className="admin-quick"><button onClick={()=>setTab('packages')}>Manage packages</button><button onClick={()=>setTab('users')}>View registered users</button><button onClick={()=>setTab('bookings')}>View all bookings</button></div></div></>}
          {tab==='packages' && <><div className="admin-card"><h3>{editing?'Edit package':'Add a travel package'}</h3><form className="package-form" onSubmit={savePackage}><label>Package name<input value={draft.name} onChange={e=>setDraft({...draft,name:e.target.value})} required /></label><label>Destination<input value={draft.destination} onChange={e=>setDraft({...draft,destination:e.target.value})} required /></label><label>Price (USD)<input type="number" min="1" value={draft.price} onChange={e=>setDraft({...draft,price:e.target.value})} required /></label><label>Duration (days)<input type="number" min="1" value={draft.days} onChange={e=>setDraft({...draft,days:e.target.value})} required /></label><label className="wide">Description<input value={draft.description} onChange={e=>setDraft({...draft,description:e.target.value})} /></label><div className="wide form-actions"><button className="admin-primary"><Plus size={16}/>{editing?'Save changes':'Add package'}</button>{editing&&<button type="button" className="admin-secondary" onClick={()=>{setEditing(null);setDraft({name:'',destination:'',price:'',days:'',description:''})}}>Cancel</button>}</div></form></div><div className="admin-card"><h3>All packages ({packages.length})</h3>{packages.length===0?<p className="admin-empty">No packages yet. Add your first package above.</p>:<div className="admin-package-list">{packages.map(p=><div className="admin-package" key={p.id}><div><b>{p.name}</b><span>{p.destination} · {p.days} days · ${p.price}</span></div><div className="admin-row-actions"><button onClick={()=>editPackage(p)} aria-label="Edit"><Pencil size={16}/></button><button onClick={()=>removePackage(p.id)} aria-label="Delete"><Trash2 size={16}/></button></div></div>)}</div>}</div></>}
          {tab==='users' && <div className="admin-card"><h3>Registered users ({users.length})</h3><div className="admin-table-wrap"><table><thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Joined</th></tr></thead><tbody>{users.map(u=><tr key={u.id}><td>{u.name}</td><td>{u.email}</td><td>{u.phone||'—'}</td><td>{u.createdAt?new Date(u.createdAt).toLocaleDateString():'—'}</td></tr>)}</tbody></table></div>{users.length===0&&<p className="admin-empty">No registered users yet.</p>}</div>}
          {tab==='bookings' && <div className="admin-card"><h3>All bookings ({bookings.length})</h3><BookingTable bookings={bookings.slice().reverse()}/></div>}
        </main>
      </div>}
    </section>
  </div>
}

function BookingTable({ bookings }) { return <div className="admin-table-wrap"><table><thead><tr><th>Booking ID</th><th>Customer</th><th>Item</th><th>Amount</th><th>Status</th></tr></thead><tbody>{bookings.map(b=><tr key={b.id}><td>{b.id}</td><td>{b.userName}<small>{b.userEmail}</small></td><td>{b.type}: {b.title}</td><td>${b.amount}</td><td><span className="admin-status">{b.status}</span></td></tr>)}</tbody></table>{bookings.length===0&&<p className="admin-empty">No bookings have been made yet.</p>}</div> }

export default function App() {
  const [adminOpen, setAdminOpen] = useState(false)
  useEffect(() => {
    const parsed = new DOMParser().parseFromString(legacyHtml, 'text/html')
    const root = document.getElementById('legacy-root')
    root.innerHTML = parsed.body.innerHTML.replace(/<script[\s\S]*?<\/script>/gi, '')
    parsed.querySelectorAll('style').forEach(s => { const style=document.createElement('style'); style.textContent=s.textContent; style.dataset.legacy='true'; document.head.appendChild(style) })
    const scriptText = [...parsed.scripts].map(s=>s.textContent).join('\n')
    const script = document.createElement('script'); script.textContent = scriptText; document.body.appendChild(script)
    const header = document.querySelector('.header-right')
    if (header && !document.getElementById('adminPortalBtn')) {
      const admin = document.createElement('button'); admin.id='adminPortalBtn'; admin.className='btn btn-ghost-light btn-sm'; admin.textContent='Admin'; admin.addEventListener('click',()=>window.dispatchEvent(new Event('voyagex:admin'))); header.insertBefore(admin, header.firstChild)
    }
    const logout = document.getElementById('registerBtn')
    logout?.addEventListener('click', e=>{ if (localStorage.getItem('voyagex_session')) { e.stopImmediatePropagation(); localStorage.removeItem('voyagex_session'); const s=document.getElementById('signInBtn'); if(s)s.textContent='Sign In'; logout.textContent='Register'; document.getElementById('mobileMenu')?.classList.remove('open'); window.dispatchEvent(new Event('voyagex:loggedout')); } }, true)
    const signIn = document.getElementById('signInBtn')
    signIn?.addEventListener('click',()=>{ const session=read('voyagex_session',null); if(session){ window.dispatchEvent(new Event('voyagex:account')); } })
    const onAdmin=()=>setAdminOpen(true); window.addEventListener('voyagex:admin',onAdmin)
    const session=read('voyagex_session',null); if(session && signIn) signIn.textContent=session.name||'Account'
    return ()=>{ window.removeEventListener('voyagex:admin',onAdmin); document.querySelectorAll('style[data-legacy="true"]').forEach(s=>s.remove()); script.remove(); root.innerHTML='' }
  }, [])
  return <><div id="legacy-root" />{adminOpen && <AdminPanel onClose={()=>setAdminOpen(false)}/>}</>
}
